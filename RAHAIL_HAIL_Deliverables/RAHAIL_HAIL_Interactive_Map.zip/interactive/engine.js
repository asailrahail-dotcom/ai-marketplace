/* RAHAIL | HAIL — cinematic journey map engine.
   Everything on screen is a pure function of time: render(t).
   The same engine drives: interactive playback, MP4 frame capture and PDF pages. */
(function () {
  const J = window.JOURNEY;
  const $ = (s, r = document) => r.querySelector(s);
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const seg = (t, a, b) => clamp((t - a) / (b - a));
  const eio = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;          // easeInOutCubic
  const eo = t => 1 - Math.pow(1 - t, 3);                                               // easeOutCubic
  const eo5 = t => 1 - Math.pow(1 - t, 5);
  const ei = t => t * t * t;
  const smooth = t => t * t * (3 - 2 * t);
  const W = 1920, H = 1080;
  const P = new URLSearchParams(location.search);
  const PRINT = P.has('print');

  /* ---------------- data ---------------- */
  const stations = [];
  J.days.forEach((d, di) => d.stations.forEach((s, si) => stations.push(Object.assign({}, s, { day: d, di, si, gi: stations.length }))));
  const N = stations.length;
  const toAr = n => String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);

  /* ---------------- timeline ---------------- */
  const D = { intro: 14, overview: 5.5, day: 5.6, st: 5.2, finale: 5, closing: 11 };
  const T = []; let acc = 0;
  const push = (type, dur, o = {}) => { T.push(Object.assign({ type, t0: acc, dur }, o)); acc += dur; };
  push('intro', D.intro); push('overview', D.overview);
  let prev = null;
  J.days.forEach((d, di) => {
    push('day', D.day, { day: d, di, prevSt: prev });
    stations.filter(s => s.di === di).forEach(s => { push('st', D.st, { st: s, prevSt: prev }); prev = s; });
  });
  push('finale', D.finale, { prevSt: prev }); push('closing', D.closing);
  const DUR = acc;
  stations.forEach(s => { const g = T.find(x => x.st === s); s.t0 = g.t0; s.hold = g.t0 + 3.4; });

  /* ---------------- camera ---------------- */
  const CAM_OVER = { x: 1720, y: 900, z: 0.6 };
  const layoutOf = s => (PRINT && s.win === 'full') ? (s.gi % 2 ? 'left' : 'right') : s.win;
  function stCam(s) {
    const L = layoutOf(s), z = 1.15;
    // pin placement on screen for each layout
    const sp = L === 'full' ? [960, 540] : L === 'right' ? [430, 300] : [1490, 300];
    return { x: s.map[0] - (sp[0] - W / 2) / z, y: s.map[1] - (sp[1] - H / 2) / z, z };
  }
  const camLerp = (a, b, k, hop = 0) => {
    const z = Math.exp(lerp(Math.log(a.z), Math.log(b.z), k)) * (1 - hop * Math.sin(Math.PI * k));
    return { x: lerp(a.x, b.x, k), y: lerp(a.y, b.y, k), z };
  };
  const w2s = (c, x, y) => [(x - c.x) * c.z + W / 2, (y - c.y) * c.z + H / 2];

  /* ---------------- DOM ---------------- */
  const stage = $('#stage');
  stage.innerHTML = `
  <div id="map"><div id="world"><img class="art" src="map.svg"><svg id="routes" width="3200" height="1800" viewBox="0 0 3200 1800">
    <defs><radialGradient id="headGrad"><stop offset="0" stop-color="#fff7e2"/><stop offset=".25" stop-color="#ffd690" stop-opacity=".9"/><stop offset="1" stop-color="#ffb347" stop-opacity="0"/></radialGradient></defs>
    <g id="ghosts"></g><g id="glows"></g><g id="lits"></g><g id="heads"></g></svg><div id="pins"></div><div id="mlabels"></div></div>
    <div id="mapTitle"><div class="a">مسار الرحلة</div><div class="e">THE JOURNEY MAP</div></div>
    <svg id="compass" viewBox="0 0 120 120"><circle cx="60" cy="60" r="44" fill="none" stroke="#d9b26f" stroke-opacity=".5"/><circle cx="60" cy="60" r="36" fill="none" stroke="#d9b26f" stroke-opacity=".25" stroke-dasharray="2 5"/><path d="M60 8 L67 60 L60 112 L53 60Z" fill="#d9b26f" fill-opacity=".55"/><path d="M8 60 L60 54 L112 60 L60 66Z" fill="#d9b26f" fill-opacity=".25"/><text x="60" y="6" fill="#f1d7a2" font-family="Jost" font-size="11" text-anchor="middle">N</text></svg>
  </div>
  <div id="land"><img class="sky"><div class="layer" id="bigtitle">HAIL</div><img class="fg"><svg id="trail" viewBox="0 0 1920 1080"></svg>
    <img id="landLogo" src="img/logo_cream.png"><div id="landText"></div><div id="dayCard"></div></div>
  <div id="scrim"></div>
  <div id="winShadow"></div>
  <div id="win"><img class="ph"><div class="shade"></div><div class="frame"></div></div>
  <div id="inset"><img></div>
  <div id="cap"></div>
  <div id="hud"><img id="hudLogo" src="img/logo_cream.png"><div id="hudPlace">HAIL<b>حائل</b></div><div id="hudDay"></div>
    <div id="mini"><img src="map.svg"><svg viewBox="0 0 3200 1800" preserveAspectRatio="none"><path id="miniGhost" fill="none" stroke="#e9c48b" stroke-opacity=".35" stroke-width="10" stroke-dasharray="10 30"/><path id="miniLit" fill="none" stroke="#f6d79e" stroke-width="14" stroke-linecap="round"/><circle id="miniDot" r="34" fill="url(#headGrad)"/><circle id="miniDot2" r="12" fill="#fff4dc"/></svg><div class="mk">HAIL · MAP</div></div>
    <div id="prog"><div class="line"></div><div class="fill"></div></div></div>
  <div id="grain"></div><div id="vig"></div><div id="black"></div>`;

  const world = $('#world'), mapEl = $('#map'), land = $('#land'), win = $('#win'), winImg = $('#win .ph'), winFrame = $('#win .frame'), winShade = $('#win .shade');
  const winShadow = $('#winShadow'), inset = $('#inset'), insetImg = $('#inset img'), cap = $('#cap'), scrim = $('#scrim');
  const sky = $('#land .sky'), fg = $('#land .fg'), big = $('#bigtitle'), trail = $('#trail'), landLogo = $('#landLogo'), landText = $('#landText'), dayCard = $('#dayCard');
  const hudLogo = $('#hudLogo'), hudPlace = $('#hudPlace'), hudDay = $('#hudDay'), prog = $('#prog'), mini = $('#mini'), black = $('#black'), grain = $('#grain');
  const mapTitle = $('#mapTitle'), compass = $('#compass');

  /* route geometry (Catmull-Rom → cubic Béziers) */
  const pts = stations.map(s => s.map);
  const segs = [];
  const NS = 'http://www.w3.org/2000/svg';
  for (let i = 1; i < N; i++) {
    const p0 = pts[Math.max(0, i - 2)], p1 = pts[i - 1], p2 = pts[i], p3 = pts[Math.min(N - 1, i + 1)];
    let c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    const same = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 30;
    let d = `M${p1[0]},${p1[1]} C${c1[0]},${c1[1]} ${c2[0]},${c2[1]} ${p2[0]},${p2[1]}`;
    if (same) d = `M${p1[0]},${p1[1]} C${p1[0] + 120},${p1[1] - 140} ${p2[0] - 120},${p2[1] - 140} ${p2[0]},${p2[1]}`;
    const mk = (g, cls) => { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); p.setAttribute('class', cls); $(g).appendChild(p); return p; };
    const ghost = mk('#ghosts', 'ghost'), glow = mk('#glows', 'glow'), lit = mk('#lits', 'lit');
    const L = lit.getTotalLength();
    [glow, lit].forEach(p => { p.style.strokeDasharray = L; p.style.strokeDashoffset = L; });
    const head = document.createElementNS(NS, 'circle'); head.setAttribute('class', 'head'); head.setAttribute('r', 40); head.style.opacity = 0; $('#heads').appendChild(head);
    segs.push({ ghost, glow, lit, head, L, d });
  }
  const fullD = segs.map((s, i) => i ? s.d.replace(/^M[^C]+/, '') : s.d).join(' ');
  $('#miniGhost').setAttribute('d', fullD);
  const miniLit = $('#miniLit'); miniLit.setAttribute('d', fullD); const miniLen = miniLit.getTotalLength();
  miniLit.style.strokeDasharray = miniLen;
  // cumulative fraction of mini path at each station
  const segLenCum = [0]; segs.forEach(s => segLenCum.push(segLenCum[segLenCum.length - 1] + s.L));

  /* pins */
  const chevron = `<svg viewBox="0 0 44 30"><path d="M4 22 L22 6 L40 22" fill="none" stroke="#d9b26f" stroke-width="3"/><path d="M14 22 L22 29 L30 22Z" fill="#d9b26f"/></svg>`;
  const clock = `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5" fill="none" stroke="#d9b26f" stroke-width="1.4"/><path d="M12 6.5 V12 L15.5 14" fill="none" stroke="#f1d7a2" stroke-width="1.6" stroke-linecap="round"/></svg>`;
  const pins = stations.map(s => {
    const p = el('div', 'pin'); p.style.left = s.map[0] + 'px'; p.style.top = s.map[1] + 'px';
    p.innerHTML = `<div class="pi"><div class="ring"></div><div class="dot"></div><div class="lab">${s.place}<b>${String(s.gi + 1).padStart(2, '0')}</b></div></div>`;
    p.dataset.i = s.gi; $('#pins').appendChild(p);
    return { root: p, pi: p.firstChild, ring: p.querySelector('.ring'), dot: p.querySelector('.dot'), lab: p.querySelector('.lab') };
  });
  const MLAB = [
    { a: 'جبال أجا', e: 'AJA MOUNTAINS', x: 760, y: 900, r: -52 },
    { a: 'جبال سلمى', e: 'SALMA MOUNTAINS', x: 2690, y: 1370, r: -48 },
    { a: 'النفود الكبير', e: 'THE GREAT NAFUD', x: 980, y: 210, r: 0 },
    { a: 'حائل', e: 'HAIL', x: 1850, y: 880, r: 0, big: 1 },
  ].map(m => { const d = el('div', 'mlabel', `<div class="a">${m.a}</div><div class="e">${m.e}</div>`); d.style.left = m.x + 'px'; d.style.top = m.y + 'px'; $('#mlabels').appendChild(d); return Object.assign(m, { el: d }); });

  /* progress bar */
  const progX = i => 1 - (i / (N - 1));   // RTL: first station on the right
  stations.forEach(s => { const k = el('div', 'tick'); k.style.left = (progX(s.gi) * 100) + '%'; k.dataset.i = s.gi; prog.appendChild(k); s.tick = k; });
  J.days.forEach((d, di) => { const first = stations.find(s => s.di === di); const l = el('div', 'dl', d.name); l.style.left = (progX(first.gi) * 100) + '%'; prog.appendChild(l); d.lbl = l; });
  const progFill = $('#prog .fill');

  /* grain frames (deterministic) */
  const grains = []; let seed = 12345; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let g = 0; g < 6; g++) {
    const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d'); const im = x.createImageData(256, 256);
    for (let i = 0; i < im.data.length; i += 4) { const v = rnd() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; }
    x.putImageData(im, 0, 0); grains.push(`url(${c.toDataURL()})`);
  }

  /* light trail (candle path) for landscapes */
  const trailPaths = {
    opening: 'M-40,1075 C320,1050 640,1010 880,955 C1050,915 1170,868 1262,836',
    closing: 'M-40,1000 C300,960 560,900 800,860 C1050,820 1300,840 1500,900 C1680,950 1820,1000 1980,1020',
  };
  const trailDots = {};
  for (const k in trailPaths) {
    const g = document.createElementNS(NS, 'g'); g.dataset.k = k; trail.appendChild(g);
    const path = document.createElementNS(NS, 'path'); path.setAttribute('d', trailPaths[k]); path.setAttribute('fill', 'none');
    path.setAttribute('stroke', '#ffcf86'); path.setAttribute('stroke-width', '3'); path.setAttribute('stroke-opacity', '.25'); g.appendChild(path);
    const L = path.getTotalLength(); const dots = [];
    for (let i = 0; i < 70; i++) {
      const p = path.getPointAtLength(L * i / 69); const c = document.createElementNS(NS, 'circle');
      const yy = p.y; const sz = Math.max(.8, 1 + (yy - 820) / 70);
      c.setAttribute('cx', p.x + (i % 2 ? 9 : -9) * sz * .6); c.setAttribute('cy', p.y); c.setAttribute('r', Math.max(1.5, sz * 1.6)); c.setAttribute('fill', 'url(#tg)'); g.appendChild(c); dots.push(c);
    }
    trailDots[k] = { g, path, L, dots };
  }
  trail.insertAdjacentHTML('afterbegin', '<defs><radialGradient id="tg"><stop offset="0" stop-color="#fff3d6"/><stop offset=".3" stop-color="#ffc768"/><stop offset="1" stop-color="#ff9a3c" stop-opacity="0"/></radialGradient></defs>');

  /* image sets */
  const IMG = id => `img/${id}.jpg`;
  const landSrc = k => ({ sky: `img/L_${k}_sky.jpg`, fg: `img/L_${k}_fg.png` });

  /* ---------------- helpers for frame state ---------------- */
  let curLand = null, curCap = null, curWin = null, curDayCard = null, curLandText = null;
  function setLand(k) { if (curLand === k) return; curLand = k; const s = landSrc(k); sky.src = s.sky; fg.src = s.fg; }
  function setLandText(key, html) { if (curLandText === key) return; curLandText = key; landText.innerHTML = html; }
  function words(t) { return t.split(' ').map(w => `<span>${w}</span>`).join(' '); }
  function setCap(s) {
    if (curCap === s.id) return; curCap = s.id;
    cap.innerHTML = `<div class="kick"><span>${s.day.en}</span><i></i><span class="ar">${s.day.name} · ${s.day.title}</span></div>
      <div class="num"><small>/ ${String(N).padStart(2, '0')}</small>${String(s.gi + 1).padStart(2, '0')}</div>
      <div class="ti">${words(s.title)}</div><div class="en">${s.en}</div><div class="de">${s.desc}</div>
      <div class="meta"><div class="tm">${clock}<span class="c">${s.time}</span>${s.est ? '<span class="e">توقيت تقديري</span>' : ''}</div><div class="pl">${chevron}${s.place}</div></div>`;
  }
  function setWin(s) { if (curWin === s.id) return; curWin = s.id; winImg.src = IMG(s.id); if (s.inset) insetImg.src = IMG(s.id + '_in'); }
  function setDayCard(d, di) {
    if (curDayCard === d.id) return; curDayCard = d.id;
    dayCard.innerHTML = `<div style="position:absolute;inset:0;background:linear-gradient(300deg,rgba(5,7,13,.85) 0%,rgba(5,7,13,.45) 35%,rgba(5,7,13,0) 60%)"></div><div class="idx">0${di + 1}</div><div class="wrap"><div class="en">DAY 0${di + 1} · ${d.en}</div><div class="nm">${d.name}</div><div class="ti">${d.title}</div><div class="su">${d.subtitle}</div><div class="bar"></div></div>`;
  }
  const winRect = L => L === 'full' ? [0, 0, W, H] : L === 'right' ? [760, 150, 1060, 760] : [100, 150, 1060, 760];
  const capPos = L => L === 'full' ? { right: 120, bottom: 120, width: 900 } : L === 'right' ? { left: 100, top: 400, width: 600 } : { left: 1240, top: 400, width: 600 };

  /* ---------------- render ---------------- */
  function hideAll() {
    land.style.opacity = 0; win.style.opacity = 0; winShadow.style.opacity = 0; inset.style.opacity = 0; cap.style.opacity = 0; scrim.style.opacity = 0;
    mini.style.opacity = 0; mapTitle.style.opacity = 0; dayCard.style.opacity = 0; landText.style.opacity = 0; landText.style.left = '0'; landText.style.right = '0'; landText.style.textAlign = 'center'; landLogo.style.opacity = 0; big.style.opacity = 0;
    compass.style.opacity = 0; trail.style.opacity = 0; sky.style.opacity = 1; fg.style.opacity = 1;
  }
  function clampCam(c) {
    const z = Math.max(c.z, 0.6), hw = W / 2 / z, hh = H / 2 / z;
    return { x: clamp(c.x, hw, 3200 - hw), y: clamp(c.y, hh, 1800 - hh), z };
  }
  function placeWorld(c) {
    c = clampCam(c);
    world.style.transform = `translate(${W / 2 - c.x * c.z}px,${H / 2 - c.y * c.z}px) scale(${c.z})`;
    world.style.setProperty('--k', 1 / c.z);
    pins.forEach(p => p.pi.style.transform = `scale(${1 / c.z})`);
    MLAB.forEach(m => m.el.style.transform = `translate(-50%,-50%) rotate(${m.r}deg) scale(${(m.big ? 1.25 : 1) / Math.max(c.z, .55) * .75})`);
    segs.forEach(s => s.head.setAttribute('r', 46 / c.z));
  }
  function routeState(upto, frac) { // segments < upto fully lit, segment upto partially (frac)
    segs.forEach((s, i) => {
      const k = i < upto ? 1 : i === upto ? frac : 0;
      const off = s.L * (1 - k);
      s.lit.style.strokeDashoffset = off; s.glow.style.strokeDashoffset = off;
      const showHead = i === upto && frac > 0 && frac < 1;
      s.head.style.opacity = showHead ? 1 : 0;
      if (showHead) { const p = s.lit.getPointAtLength(s.L * frac); s.head.setAttribute('cx', p.x); s.head.setAttribute('cy', p.y); }
    });
    const uu = Math.max(0, Math.min(upto, segs.length)); const len = upto < 0 ? 0 : segLenCum[uu] + (uu < segs.length ? segs[uu].L * frac : 0);
    miniLit.style.strokeDashoffset = miniLen * (1 - len / segLenCum[segLenCum.length - 1]);
  }
  function pinState(cur, arrive, t, show = 1) {
    pins.forEach((p, i) => {
      const visited = i < cur || (i === cur && arrive >= 1);
      const isCur = i === cur;
      p.root.style.opacity = show;
      p.dot.style.background = visited || (isCur && arrive > 0) ? '#f1d7a2' : '#0a1222';
      p.dot.style.transform = `scale(${isCur ? 1 + .5 * arrive : visited ? .8 : .7})`;
      const ph = isCur ? ((t * .9) % 1) : 0;
      p.ring.style.opacity = isCur ? arrive * (1 - ph) : 0; p.ring.style.transform = `scale(${.6 + ph * 1.4})`;
      p.lab.style.opacity = isCur ? arrive : 0;
    });
  }
  function hud(on, s, t) {
    hudLogo.style.opacity = on; hudPlace.style.opacity = on * .9; prog.style.opacity = on;
    hudDay.style.opacity = s ? on : 0;
    if (s) hudDay.textContent = `${s.day.name} · ${s.day.title}`;
    const ci = s ? s.gi : -1;
    stations.forEach(x => x.tick.classList.toggle('on', x.gi <= ci));
    J.days.forEach((d, di) => d.lbl.classList.toggle('on', s && s.di === di));
    progFill.style.width = ci < 0 ? '0%' : ((ci / (N - 1)) * 100) + '%';
  }
  function miniState(s, op) {
    mini.style.opacity = op; if (!op) return;
    const [x, y] = s.map; ['#miniDot', '#miniDot2'].forEach(q => { $(q).setAttribute('cx', x); $(q).setAttribute('cy', y); });
  }

  function landscape(key, t, o) { // generic landscape layer with parallax (t = 0..dur)
    setLand(key);
    const k = t / o.dur;
    sky.style.transform = `translate(${lerp(o.sx0 || 0, o.sx1 || -40, k)}px,${lerp(0, 10, k)}px) scale(${lerp(1.06, 1.0, k)})`;
    fg.style.transform = `translate(${lerp(o.fx0 || 0, o.fx1 || -90, k)}px,${(o.by || 0) + lerp(o.fy0 || 30, o.fy1 || 0, eo(k))}px) scale(${lerp(1.08, 1.02, k)})`;
  }

  function render(t) {
    t = clamp(t, 0, DUR - 1e-4);
    const g = T.find(x => t >= x.t0 && t < x.t0 + x.dur) || T[T.length - 1];
    const u = t - g.t0;
    hideAll();
    black.style.opacity = 0;
    grain.style.backgroundImage = grains[Math.floor(t * 24) % 6];
    grain.style.transform = `translate(${(Math.floor(t * 24) * 37) % 20 - 10}px,${(Math.floor(t * 24) * 53) % 20 - 10}px)`;
    trail.querySelectorAll('g[data-k]').forEach(x => x.style.display = 'none');

    if (g.type === 'intro') {
      black.style.opacity = 1 - smooth(seg(u, 0.2, 2.6));
      land.style.opacity = 1 - smooth(seg(u, 11.6, 13.6));
      landscape('opening', u, { dur: 14, fy0: 80, fy1: 0, fx1: -60, by: 230 });
      fg.style.transform += ''; // keep
      // light trail (luminaria path)
      const td = trailDots.opening; td.g.style.display = ''; trail.style.opacity = 1;
      const tp = eo(seg(u, 3.0, 7.5));
      td.dots.forEach((c, i) => { const a = clamp((tp * 70 - i) / 6); c.style.opacity = a * (0.75 + 0.25 * Math.sin(t * 7 + i * 1.7)); });
      td.path.style.opacity = tp;
      // logo: appears centre, rises to a header, then docks into the HUD (morph-like)
      const la = smooth(seg(u, 2.4, 4.4)), lu = eio(seg(u, 4.6, 6.0)), ld = eio(seg(u, 9.6, 11.2));
      landLogo.style.opacity = la * (1 - seg(u, 10.7, 11.2));
      const lx = lerp(0, 1690 - 960, ld), ly = lerp(lerp(-150, -405, lu), 92 - 540, ld), ls = lerp(lerp(1, .5, lu), 150 / 420, ld);
      landLogo.style.transform = `translate(calc(-50% + ${lx}px),calc(-50% + ${ly}px)) scale(${ls * lerp(1.06, 1, la)})`;
      landLogo.style.filter = `blur(${(1 - la) * 10}px)`;
      // big HAIL rising from behind the Aja ridge
      const bt = eo5(seg(u, 5.4, 8.8));
      big.style.opacity = smooth(seg(u, 5.4, 6.6)) * (1 - smooth(seg(u, 11, 12.6)));
      big.style.transform = `translateY(${lerp(420, 190, bt)}px) scale(${lerp(.96, 1, bt) * lerp(1, 1.04, seg(u, 8.8, 14))})`;
      // tagline
      setLandText('intro', `<div class="k">RAHAIL<i></i>HAIL</div><div class="t">${J.brand.tagline}</div>`);
      landText.style.top = '640px';
      const ta = smooth(seg(u, 7.6, 9.4)); landText.style.opacity = ta * (1 - smooth(seg(u, 10.8, 12)));
      landText.style.transform = `translateY(${(1 - ta) * 24}px)`; landText.style.filter = `blur(${(1 - ta) * 6}px)`;
      // map fades in under it, from a deep zoom on the city
      const mk = smooth(seg(u, 11.4, 14));
      mapEl.style.opacity = mk; placeWorld({ x: 1850, y: 880, z: lerp(2.6, 1.6, mk) });
      routeState(-1, 0); pinState(-1, 0, t, 0);
      hud(smooth(seg(u, 10.6, 11.6)) * 1, null, t); prog.style.opacity = 0;
      return;
    }
    mapEl.style.opacity = 1;

    if (g.type === 'overview') {
      const k = eio(seg(u, 0, 3.2));
      placeWorld(camLerp({ x: 1850, y: 880, z: 1.6 }, CAM_OVER, k));
      MLAB.forEach((m, i) => m.el.style.opacity = smooth(seg(u, .8 + i * .35, 1.8 + i * .35)));
      mapTitle.style.opacity = smooth(seg(u, 1.2, 2.4)) * (1 - smooth(seg(u, 4.6, 5.4)));
      mapTitle.style.transform = `translateY(${(1 - smooth(seg(u, 1.2, 2.4))) * 20}px)`;
      compass.style.opacity = smooth(seg(u, 1.5, 3)) * .8;
      const shown = seg(u, 1.6, 4.2) * N;
      pinState(-1, 0, t, 1); pins.forEach((p, i) => { p.root.style.opacity = clamp(shown - i); });
      segs.forEach((s, i) => s.ghost.style.opacity = clamp(shown - i - 1));
      routeState(-1, 0);
      hud(1, null, t);
      // into Thursday
      return;
    }
    MLAB.forEach(m => m.el.style.opacity = 1); segs.forEach(s => s.ghost.style.opacity = 1); compass.style.opacity = .8;

    if (g.type === 'day') {
      const camBase = g.prevSt ? stCam(g.prevSt) : CAM_OVER;
      const inK = smooth(seg(u, 0, 1.1)), outK = smooth(seg(u, 4.5, 5.6));
      placeWorld({ x: camBase.x, y: camBase.y, z: camBase.z * lerp(1, 1.5, inK) * lerp(1.25, 1, outK) });
      const done = g.prevSt ? g.prevSt.gi : -1;
      routeState(done, 1); pinState(done, 1, t, 1);
      land.style.opacity = inK * (1 - outK);
      landscape(g.day.id, u, { dur: D.day, fy0: 40, fy1: -10, fx0: 30, fx1: -60 });
      setDayCard(g.day, g.di);
      const a = eo(seg(u, .7, 2.0)); dayCard.style.opacity = a * (1 - outK);
      dayCard.querySelector('.wrap').style.transform = `translateY(${(1 - a) * 40}px)`;
      dayCard.querySelector('.wrap').style.filter = `blur(${(1 - a) * 8}px)`;
      dayCard.querySelector('.bar').style.width = (520 * eo(seg(u, 1.4, 3))) + 'px';
      dayCard.querySelector('.idx').style.opacity = smooth(seg(u, 1.2, 2.4)) * .9;
      hud(1 - .6 * inK * (1 - outK), g.prevSt, t);
      return;
    }

    if (g.type === 'st') {
      const s = g.st, L = layoutOf(s);
      const from = g.prevSt ? stCam(g.prevSt) : CAM_OVER, to = stCam(s);
      const dist = Math.hypot(to.x - from.x, to.y - from.y);
      const tk = eio(seg(u, 0, 1.55));
      let cam = camLerp(from, to, tk, clamp(dist / 2600) * .45);
      // window open/close
      const op = eio(seg(u, 1.35, 2.3)), cl = eio(seg(u, 4.55, 5.2)), wp = op * (1 - cl);
      if (L === 'full') cam = { x: cam.x, y: cam.y, z: cam.z * (1 + 0.9 * wp) };
      cam = clampCam(cam); placeWorld(cam);
      routeState(s.gi - 1, clamp((u - .1) / 1.35));
      if (s.gi === 0) routeState(-1, 0);
      const arrive = seg(u, 1.25, 1.6);
      pinState(s.gi, arrive, t, 1);
      hud(1, s, t);
      // window rect: pin → target
      setWin(s);
      MLAB.forEach(m => m.el.style.opacity = 1 - .85 * wp);
      const [px, py] = w2s(cam, s.map[0], s.map[1]);
      const R = winRect(L), r0 = [px - 12, py - 12, 24, 24];
      const rr = [0, 1, 2, 3].map(i => lerp(r0[i], R[i], wp));
      if (wp > 0.001) {
        win.style.opacity = clamp(wp * 4);
        Object.assign(win.style, { left: rr[0] + 'px', top: rr[1] + 'px', width: rr[2] + 'px', height: rr[3] + 'px', borderRadius: lerp(14, L === 'full' ? 0 : 4, wp) + 'px' });
        winShadow.style.opacity = L === 'full' ? 0 : wp;
        Object.assign(winShadow.style, { left: rr[0] + 'px', top: rr[1] + 'px', width: rr[2] + 'px', height: rr[3] + 'px' });
        // photo anchored to final rect (mask reveal) + Ken Burns
        const kb = seg(u, 1.35, 5.2), dir = s.gi % 2 ? 1 : -1;
        const iw = R[2] * 1.12, ih = iw * 1296 / 2304 < R[3] * 1.12 ? R[3] * 1.12 : iw * 1296 / 2304, iw2 = ih * 2304 / 1296 > iw ? ih * 2304 / 1296 : iw;
        Object.assign(winImg.style, { width: iw2 + 'px', height: ih + 'px', left: (R[0] - rr[0] + (R[2] - iw2) / 2) + 'px', top: (R[1] - rr[1] + (R[3] - ih) / 2) + 'px' });
        winImg.style.transform = `translate(${dir * lerp(-24, 24, kb)}px,${lerp(8, -8, kb)}px) scale(${lerp(1.16, 1.0, eo(seg(u, 1.35, 3))) * lerp(1, 1.05, kb)})`;
        winFrame.style.opacity = L === 'full' ? (1 - wp) : 1;
        winShade.style.background = L === 'full'
          ? 'linear-gradient(0deg,rgba(5,7,13,.92) 0%,rgba(5,7,13,.55) 28%,rgba(5,7,13,0) 55%),linear-gradient(270deg,rgba(5,7,13,.55),rgba(5,7,13,0) 55%)'
          : 'linear-gradient(0deg,rgba(5,7,13,.35),rgba(5,7,13,0) 40%)';
      }
      // caption
      setCap(s);
      const ca = seg(u, 1.9, 2.9), co = smooth(seg(u, 4.45, 4.85));
      cap.style.opacity = (ca > 0 ? 1 : 0) * (1 - co);
      Object.assign(cap.style, { left: '', right: '', top: '', bottom: '' });
      const cp = capPos(L); for (const k in cp) cap.style[k] = cp[k] + 'px';
      const kick = cap.querySelector('.kick'), num = cap.querySelector('.num'), ti = cap.querySelectorAll('.ti span'), en = cap.querySelector('.en'), de = cap.querySelector('.de'), meta = cap.querySelector('.meta');
      const fade = (e, a, b, dy = 18) => { const k = eo(seg(u, a, b)); e.style.opacity = k; e.style.transform = `translateY(${(1 - k) * dy}px)`; };
      fade(kick, 1.9, 2.5); fade(num, 2.0, 2.7, 30);
      ti.forEach((w, i) => { const k = eo(seg(u, 2.15 + i * .12, 2.85 + i * .12)); w.style.opacity = k; w.style.transform = `translateY(${(1 - k) * 34}px)`; w.style.filter = `blur(${(1 - k) * 8}px)`; });
      fade(en, 2.55, 3.1); fade(de, 2.7, 3.3); fade(meta, 2.9, 3.5);
      if (L !== 'full') { scrim.style.opacity = wp * .85; scrim.style.background = L === 'right' ? 'linear-gradient(90deg,rgba(5,7,13,.85) 0%,rgba(5,7,13,.5) 38%,rgba(5,7,13,0) 60%)' : 'linear-gradient(270deg,rgba(5,7,13,.85) 0%,rgba(5,7,13,.5) 38%,rgba(5,7,13,0) 60%)'; }
      // detail inset
      if (s.inset) {
        const ia = eo(seg(u, 2.6, 3.4)) * (1 - smooth(seg(u, 4.4, 4.8)));
        inset.style.opacity = ia;
        const ipos = L === 'full' ? [150, 330] : L === 'right' ? [R[0] + R[2] - 230, R[1] + R[3] - 310] : [R[0] - 70, R[1] + R[3] - 310];
        inset.style.left = ipos[0] + 'px'; inset.style.top = ipos[1] + 'px';
        inset.style.transform = `translateY(${(1 - ia) * 60}px)`;
        insetImg.style.transform = `scale(${lerp(1.1, 1, seg(u, 2.6, 5))})`;
      }
      miniState(s, L === 'full' ? smooth(seg(u, 2.3, 3)) * (1 - smooth(seg(u, 4.4, 4.9))) : 0);
      return;
    }

    if (g.type === 'finale') {
      const last = g.prevSt; const k = eio(seg(u, 0, 2.4));
      placeWorld(camLerp(stCam(last), { x: 1880, y: 1060, z: 0.74 }, k, 0)); MLAB.forEach(m => m.el.style.opacity = 1 - .6 * k);
      routeState(N, 0); pinState(N - 1, 1, t, 1);
      // travelling light trails along the whole route
      segs.forEach((s, i) => {
        const ph = ((u * .9 - i * .08) % 1 + 1) % 1; const show = (i % 3 === 0) * seg(u, .6, 1.4) * (1 - seg(u, 4, 4.8));
        s.head.style.opacity = show * .9; const p = s.lit.getPointAtLength(s.L * ph); s.head.setAttribute('cx', p.x); s.head.setAttribute('cy', p.y);
      });
      const stat = (n, a, e) => `<div style="margin-bottom:34px"><div style="font:700 92px/1.05 var(--arD);color:var(--cream)">${n} <span style="font-size:52px;color:var(--gold2)">${a}</span></div><div class="k" style="text-align:right;letter-spacing:.5em;font-size:15px;margin-top:4px">${e}</div></div>`;
      setLandText('finale', `<div style="width:2px;height:0"></div>${stat('٣', 'أيام', '3 DAYS')}${stat(toAr(N), 'تجربة', N + ' EXPERIENCES')}${stat(toAr(J.brand.participants), 'مشاركة', J.brand.participants + ' GUESTS')}`);
      landText.style.top = '250px'; landText.style.left = 'auto'; landText.style.right = '150px'; landText.style.textAlign = 'right';
      const a = smooth(seg(u, 1.6, 2.6)); landText.style.opacity = a * (1 - smooth(seg(u, 4.2, 5)));
      landText.style.transform = `translateX(${(1 - a) * -30}px)`; landText.style.filter = '';
      land.style.opacity = 1; sky.style.opacity = 0; fg.style.opacity = 0;
      hud(1 - seg(u, 4, 5), last, t);
      return;
    }

    if (g.type === 'closing') {
      sky.style.opacity = 1; fg.style.opacity = 1;
      placeWorld(CAM_OVER); routeState(N, 0); pinState(N - 1, 1, t, 1);
      const inK = smooth(seg(u, 0, 1.6));
      land.style.opacity = inK;
      landscape('closing', u, { dur: D.closing, fy0: 60, fy1: 0, fx0: 0, fx1: -70 });
      const td = trailDots.closing; td.g.style.display = ''; trail.style.opacity = 1;
      const tp = eo(seg(u, 1.0, 5));
      td.dots.forEach((c, i) => { const a = clamp((tp * 70 - i) / 6); c.style.opacity = a * (0.75 + 0.25 * Math.sin(t * 7 + i * 1.7)); }); td.path.style.opacity = tp * .8;
      setLandText('closing', `<div class="t" style="font-size:66px">من حائل… نأخذ الذكريات</div><div class="k" style="margin-top:22px">AJA<i></i>SALMA<i></i>HAIL</div>`);
      landText.style.top = '640px';
      const a = smooth(seg(u, 1.6, 3.2)), b = smooth(seg(u, 5.2, 6.2));
      landText.style.opacity = a * (1 - b); landText.style.filter = `blur(${(1 - a) * 6}px)`; landText.style.transform = `translateY(${(1 - a) * 20}px)`;
      const la = smooth(seg(u, 5.8, 7.6));
      landLogo.style.opacity = la; landLogo.style.filter = `blur(${(1 - la) * 10}px)`;
      landLogo.style.transform = `translate(-50%,calc(-50% - 120px)) scale(${lerp(1.08, 1, la) * lerp(1, 1.03, seg(u, 7.6, 11))})`;
      setDayCardTag(u);
      hud(0, null, t);
      black.style.opacity = smooth(seg(u, 9.6, 11));
      return;
    }
  }
  function setDayCardTag(u) {
    if (curDayCard !== 'closing') { curDayCard = 'closing'; dayCard.innerHTML = `<div style="position:absolute;left:0;right:0;top:660px;text-align:center"><div style="font:700 44px var(--arD);color:var(--gold2)">نطوّر الوجهة، ندير التجربة</div><div style="font:300 18px var(--en);letter-spacing:.6em;color:rgba(240,226,200,.7);margin-top:18px;padding-left:.6em">RAHAIL.SA</div></div>`; }
    const a = smooth(seg(u, 7, 8.4)); dayCard.style.opacity = a; dayCard.firstChild.style.transform = `translateY(${(1 - a) * 18}px)`;
  }

  /* ---------------- boot & playback ---------------- */
  async function ready() {
    await document.fonts.ready;
    const urls = new Set(['map.svg', 'img/logo_cream.png']);
    ['opening', 'thu', 'fri', 'sat', 'closing'].forEach(k => { const s = landSrc(k); urls.add(s.sky); urls.add(s.fg); });
    stations.forEach(s => { urls.add(IMG(s.id)); if (s.inset) urls.add(IMG(s.id + '_in')); });
    await Promise.all([...urls].map(u => new Promise(r => { const i = new Image(); i.onload = i.onerror = () => (i.decode ? i.decode().catch(() => { }).then(r) : r()); i.src = u; })));
    // warm up font glyphs used in captions
    await Promise.all(['IBM Plex Sans Arabic', 'Amiri', 'Jost'].flatMap(f => [300, 400, 500, 700].map(w => document.fonts.load(`${w} 40px "${f}"`, 'رحائل HAIL 0123'))));
  }
  function fit() { const s = Math.min(innerWidth / W, innerHeight / H); stage.style.transform = `translate(${(innerWidth - W * s) / 2}px,${(innerHeight - H * s) / 2}px) scale(${s})`; }

  window.RAHAIL = { render, DUR, T, stations, ready, D };
  window.__render = t => render(t);
  window.__duration = DUR;
  window.__ready = ready().then(() => { render(0); return true; });

  if (document.body.classList.contains('cap')) { stage.style.transform = 'none'; return; }
  fit(); addEventListener('resize', fit);
  // interactive player
  let playing = true, t0 = performance.now(), tNow = +(P.get('t') || 0);
  const ctl = document.createElement('div'); ctl.id = 'ctl';
  ctl.innerHTML = `<button data-a="next">التالي ◂</button><button data-a="play">إيقاف</button><button data-a="prev">▸ السابق</button><span class="t"></span><button data-a="restart">↺ من البداية</button>`;
  document.body.appendChild(ctl);
  const tl = ctl.querySelector('.t'), pb = ctl.querySelector('[data-a=play]');
  const marks = () => T.filter(x => x.type !== 'overview').map(x => x.st ? x.st.hold : x.type === 'day' ? x.t0 + 2.6 : x.type === 'intro' ? 9.5 : x.t0 + 3);
  const jump = tt => { tNow = clamp(tt, 0, DUR - .01); t0 = performance.now() - tNow * 1000; render(tNow); };
  const go = d => { const m = marks(); const cur = tNow + (d > 0 ? .05 : -.3); const nxt = d > 0 ? m.find(x => x > cur) : [...m].reverse().find(x => x < cur); if (nxt != null) jump(nxt); };
  ctl.addEventListener('click', e => {
    const a = e.target.dataset.a; if (!a) return;
    if (a === 'play') { playing = !playing; pb.textContent = playing ? 'إيقاف' : 'تشغيل'; t0 = performance.now() - tNow * 1000; }
    if (a === 'next') go(1); if (a === 'prev') go(-1); if (a === 'restart') { jump(0); playing = true; pb.textContent = 'إيقاف'; }
  });
  addEventListener('keydown', e => {
    if (e.key === ' ') { e.preventDefault(); pb.click(); }
    if (e.key === 'ArrowLeft') go(1); if (e.key === 'ArrowRight') go(-1);
  });
  // click a station tick or a pin → jump to that experience
  stage.addEventListener('click', e => {
    const k = e.target.closest('.tick,.pin'); if (!k) return; const s = stations[+k.dataset.i]; jump(s.hold); playing = false; pb.textContent = 'تشغيل';
  });
  let idle; addEventListener('mousemove', () => { document.body.classList.remove('idle'); clearTimeout(idle); idle = setTimeout(() => document.body.classList.add('idle'), 2500); });
  window.__ready.then(() => {
    jump(tNow);
    const loop = () => { if (playing) { tNow = (performance.now() - t0) / 1000; if (tNow >= DUR) { tNow = DUR - .01; playing = false; pb.textContent = 'تشغيل'; } render(tNow); }
      const m = Math.floor(tNow / 60), sec = Math.floor(tNow % 60); tl.textContent = `${m}:${String(sec).padStart(2, '0')} / ${Math.floor(DUR / 60)}:${String(Math.floor(DUR % 60)).padStart(2, '0')}`;
      requestAnimationFrame(loop); };
    loop();
  });
})();
